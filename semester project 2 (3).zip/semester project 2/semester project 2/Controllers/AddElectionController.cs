﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using semester_project_2.Models;

namespace semester_project_2.Controllers
{
    public class AddElectionController : Controller
    {

        [HttpGet]
        public IActionResult addElection(int candidateCount = 0)
        {
            ViewBag.count  = candidateCount;
            return View();
        }

        [HttpPost]
        public IActionResult addElection(string ElectionName, string Description, DateTime ElectionDate, int CandidateCount)
        {
            if (CandidateCount <= 0)
            {
                TempData["ElectionErrorMessage"] = "Please provide a valid number of candidates.";
                return View();
            }
            try
            {
                string query = "INSERT INTO Election (ElectionName, Description, Date) VALUES (@ElectionName, @Description, @Date)";

                using (SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ElectionSystem;Integrated Security=True;"))
                {
                    conn.Open();

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ElectionName", ElectionName);
                        cmd.Parameters.AddWithValue("@Description", Description);
                        cmd.Parameters.AddWithValue("@Date", ElectionDate);

                        cmd.ExecuteNonQuery();
                    }
                }

                TempData["ElectionSuccessMessage"] = "Election added successfully!";
                Response.Cookies.Append("Electionname", ElectionName, new CookieOptions
                {
                    Expires = DateTimeOffset.UtcNow.AddHours(1),
                    HttpOnly = true,
                    Secure = true,
                    SameSite = SameSiteMode.Strict
                });
                TempData["Key"] = CandidateCount;
                return RedirectToAction("AddCandidates");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                TempData["ElectionErrorMessage"] = "Error: " + ex.Message;
                return View();
            }
        }
        [HttpGet]
        public IActionResult AddCandidates()
        {
            int candidateCount = TempData["Key"] != null ? Convert.ToInt32(TempData["Key"]) : 0;
            ViewBag.Count = candidateCount;

            /*string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ElectionSystem;Integrated Security=True;";
            string query = "SELECT CandidateId, Name, PicUrl, Party FROM Candidate";

            List<Candidate> candidates = new List<Candidate>();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        candidates.Add(new Candidate
                        {


                        });
                        
                    }
                }
            }*/
            
           // ViewBag.Candidates = candidates;
            return View();
        }

        [HttpPost]
        public IActionResult AddCandidates(List<CandidateModel> candidates)
        {
            if (candidates == null || !candidates.Any())
            {
                // Handle the case where no candidates are provided
                return RedirectToAction("AddCandidates");
            }

            // Retrieve the election name from cookies
            string electionName = Request.Cookies["Electionname"];

            if (string.IsNullOrEmpty(electionName))
            {
                return BadRequest("Election name is not provided.");
            }

            
            var election = GetElectionDetailsByName(electionName); 

            if (election == null)
            {

                return NotFound("Election not found.");
            }
            string tableName = $"Election_{election.ElectionID}";
            CreateElectionTable(tableName, candidates);

            InsertCandidatesIntoElectionTable(tableName, election.ElectionID, candidates);

            return RedirectToAction("AddCandidates");
        }

        private void CreateElectionTable(string tableName, List<CandidateModel> candidates)
        {
            string createTableQuery = $@"
                CREATE TABLE {tableName} (
                    ID INT PRIMARY KEY IDENTITY(1,1),
                    ElectionID INT,";
                
                            for (int i = 0; i < candidates.Count; i++)
                            {
                                createTableQuery += $@"
                    Candidate{i + 1}Name NVARCHAR(100),
                    Candidate{i + 1}VoteCount INT DEFAULT 0,
                    Candidate{i + 1}ImageUrl NVARCHAR(100),
                    Candidate{i + 1}Party NVARCHAR(100),";
                            }
                
                            createTableQuery += @"
                    Win NVARCHAR(100) DEFAULT 0,          
                    Lose NVARCHAR(100) DEFAULT 0
                )";

            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ElectionSystem;Integrated Security=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(createTableQuery, conn))
                    {
                        cmd.ExecuteNonQuery();
                        Console.WriteLine("Table created successfully.");
                    }
                }
                catch (SqlException ex)
                {
                    Console.WriteLine($"Error creating table: {ex.Message}");
                }
                finally
                {
                    conn.Close();
                }
            }
        }


        private void InsertCandidatesIntoElectionTable(string tableName, int electionID, List<CandidateModel> candidates)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ElectionSystem;Integrated Security=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                // Create a list of columns and parameters for the SQL query
                List<string> candidateNames = new List<string>();
                List<string> voteCounts = new List<string>();
                List<string> candidateImageUrls = new List<string>();
                List<string> candidateParties = new List<string>();

                // Prepare the columns and corresponding parameters for candidate names, vote counts, image URLs, and parties
                for (int i = 0; i < candidates.Count; i++)
                {
                    candidateNames.Add($"Candidate{i + 1}Name");
                    voteCounts.Add($"Candidate{i + 1}VoteCount");
                    candidateImageUrls.Add($"Candidate{i + 1}ImageUrl");
                    candidateParties.Add($"Candidate{i + 1}Party");
                }

                // Construct the SQL query to insert the candidate data
                string insertQuery = $@"
        INSERT INTO {tableName} (ElectionID, {string.Join(", ", candidateNames)}, {string.Join(", ", voteCounts)}, {string.Join(", ", candidateImageUrls)}, {string.Join(", ", candidateParties)}, Win, Lose)
        VALUES (@ElectionID, {string.Join(", ", candidateNames.Select((name, index) => $"@Candidate{index + 1}Name"))}, 
                {string.Join(", ", voteCounts.Select((name, index) => $"@Candidate{index + 1}VoteCount"))},
                {string.Join(", ", candidateImageUrls.Select((name, index) => $"@Candidate{index + 1}ImageUrl"))},
                {string.Join(", ", candidateParties.Select((name, index) => $"@Candidate{index + 1}Party"))},
                @Win, @Lose)";

                // Debugging: Print out the entire query to check for correctness
                Console.WriteLine("Insert Query: " + insertQuery);

                using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                {
                    // Add parameters for ElectionID
                    cmd.Parameters.AddWithValue("@ElectionID", electionID);

                    // Add parameters for each candidate's name, vote count, image URL, and party
                    for (int i = 0; i < candidates.Count; i++)
                    {
                        cmd.Parameters.AddWithValue($"@Candidate{i + 1}Name", candidates[i].Name);
                        cmd.Parameters.AddWithValue($"@Candidate{i + 1}VoteCount", 0); // Default vote count is 0
                        cmd.Parameters.AddWithValue($"@Candidate{i + 1}ImageUrl", candidates[i].ImageUrl); // Add image URL parameter
                        cmd.Parameters.AddWithValue($"@Candidate{i + 1}Party", candidates[i].Party); // Add party parameter
                    }

                    // Assuming Win and Lose values are determined by some logic (e.g., based on the highest vote count)
                    int winValue = 0; // Example: assuming first candidate wins
                    int loseValue = 1; // Example: assuming others lose

                    cmd.Parameters.AddWithValue("@Win", winValue); // Logic to set Win
                    cmd.Parameters.AddWithValue("@Lose", loseValue); // Logic to set Lose

                    // Execute the query
                    try
                    {
                        cmd.ExecuteNonQuery();
                        Console.WriteLine("Candidates inserted successfully.");
                    }
                    catch (SqlException ex)
                    {
                        // Handle any SQL exceptions
                        Console.WriteLine($"Error inserting candidate data: {ex.Message}");
                    }
                }

                conn.Close();
            }
        }

        /*private void InsertCandidatesIntoElectionTable(string tableName, int electionID, List<CandidateModel> candidates)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ElectionSystem;Integrated Security=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                // Create a list of columns and parameters for the SQL query
                List<string> candidateNames = new List<string>();
                List<string> voteCounts = new List<string>();

                // Prepare the columns and corresponding parameters for candidate names and vote counts
                for (int i = 0; i < candidates.Count; i++)
                {
                    candidateNames.Add($"Candidate{i + 1}Name");
                    voteCounts.Add($"Candidate{i + 1}VoteCount");
                }

                // Construct the SQL query to insert the candidate data
                string insertQuery = $@"
        INSERT INTO {tableName} (ElectionID, {string.Join(", ", candidateNames)}, {string.Join(", ", voteCounts)}, Win, Lose)
        VALUES (@ElectionID, {string.Join(", ", candidateNames.Select((name, index) => $"@Candidate{index + 1}Name"))}, 
                {string.Join(", ", voteCounts.Select((name, index) => $"@Candidate{index + 1}VoteCount"))}, @Win, @Lose)";

                // Debugging: Print out the entire query to check for correctness
                Console.WriteLine("Insert Query: " + insertQuery);

                using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                {
                    // Add parameters for ElectionID
                    cmd.Parameters.AddWithValue("@ElectionID", electionID);

                    // Add parameters for each candidate's name and vote count
                    for (int i = 0; i < candidates.Count; i++)
                    {
                        cmd.Parameters.AddWithValue($"@Candidate{i + 1}Name", candidates[i].Name);
                        cmd.Parameters.AddWithValue($"@Candidate{i + 1}VoteCount", 0); // Default vote count is 0
                    }

                    // Assuming Win and Lose values are determined by some logic (e.g., based on the highest vote count)
                    int winValue = 0; // Example: assuming first candidate wins
                    int loseValue = 1; // Example: assuming others lose

                    cmd.Parameters.AddWithValue("@Win", winValue); // Logic to set Win
                    cmd.Parameters.AddWithValue("@Lose", loseValue); // Logic to set Lose

                    // Execute the query
                    try
                    {
                        cmd.ExecuteNonQuery();
                        Console.WriteLine("Candidates inserted successfully.");
                    }
                    catch (SqlException ex)
                    {
                        // Handle any SQL exceptions
                        Console.WriteLine($"Error inserting candidate data: {ex.Message}");
                    }
                }

                conn.Close();
            }
        }*/






        private Election GetElectionDetailsByName(string electionName)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ElectionSystem;Integrated Security=True;";
            string query = "SELECT ElectionID, ElectionName, Description, Date FROM Election WHERE ElectionName = @ElectionName1";

            Election election = null;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@ElectionName1", electionName);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            election = new Election
                            {
                                ElectionID = reader.GetInt32(reader.GetOrdinal("ElectionID")),
                                ElectionName = reader.GetString(reader.GetOrdinal("ElectionName")),
                                Description = reader.GetString(reader.GetOrdinal("Description")),
                                Date = reader.GetDateTime(reader.GetOrdinal("Date"))
                            };
                        }
                    }
                }
            }

            return election;
        }


        public IActionResult ElectionSuccess()
        {
            return View();
        }
        /*public IActionResult addElection(Election election)
        {
            try
            {
                // Print election details (for debugging)
                Console.WriteLine($"Election Name: {election.ElectionName}");
                Console.WriteLine($"Description: {election.Description}");
                Console.WriteLine($"Date: {election.ElectionDate}");

                // Print candidate details (for debugging)
                foreach (var candidate in election.Candidates)
                {
                    Console.WriteLine($"Candidate Name: {candidate.Name}");
                    Console.WriteLine($"Image URL: {candidate.ImageUrl}");
                    Console.WriteLine($"Party: {candidate.Party}");
                }

                // Dynamic SQL Table Creation
                string query = $@"
                CREATE TABLE {election.ElectionName.Replace(" ", "_")}_Candidates (
                    Id INT PRIMARY KEY IDENTITY,
                    Name NVARCHAR(100),
                    ImageURL NVARCHAR(255),
                    Party NVARCHAR(100)
                )";

                using (SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ElectionSystem;Integrated Security=True"))
                {
                    conn.Open();

                    // Create the table
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.ExecuteNonQuery();
                    }

                    // Insert Candidates
                    foreach (var candidate in election.Candidates)
                    {
                        string insertQuery = $@"
                        INSERT INTO {election.ElectionName.Replace(" ", "_")}_Candidates (Name, ImageURL, Party)
                        VALUES (@Name, @ImageURL, @Party)";

                        using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                        {
                            cmd.Parameters.AddWithValue("@Name", candidate.Name);
                            cmd.Parameters.AddWithValue("@ImageURL", candidate.ImageUrl);
                            cmd.Parameters.AddWithValue("@Party", candidate.Party);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }

                TempData["SuccessMessage"] = "Election and candidates added successfully!";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Failed to add election. Error: " + ex.Message;
                return View();
            }
        }
       }*/
    }

}
