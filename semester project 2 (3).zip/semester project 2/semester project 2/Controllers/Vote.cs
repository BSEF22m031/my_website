﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;

namespace semester_project_2.Controllers
{
    public class Vote : Controller
    {
        private readonly string connectionString = "Your_Connection_String_Here";

        public IActionResult vote()
        {
            var model = new Models.VoteCount();

            using (var connection = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ElectionSystem;Integrated Security=True;"))
            {
                connection.Open();
                var command = new SqlCommand("SELECT * FROM ProvisionalElectionInPunjabResult", connection);
                Console.WriteLine("Command Text: " + command.CommandText);
                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        model.Candidate1Name = reader["Candidate1Name"].ToString();
                        model.Candidate1Count = (int)reader["Candidate1Count"];
                        model.Candidate2Name = reader["Candidate2Name"].ToString();
                        model.Candidate2Count = (int)reader["Candidate2Count"];
                    }
                }
            }

            return View(model);
        }



        [HttpPost]
        public IActionResult vote(int candidate)
        {
            if (Request.Cookies["HasVoted"] != null)
            {
                TempData["Error"] = "You have already voted!";
                return RedirectToAction("Vote");
            }

            using (var connection = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ElectionSystem;Integrated Security=True;"))
            {
                connection.Open();

                SqlCommand updateCommand;
                if (candidate == 1)
                {
                    updateCommand = new SqlCommand("UPDATE ProvisionalElectionInPunjabResult SET Candidate1Count = Candidate1Count + 1", connection);
                }
                else if (candidate == 2)
                {
                    updateCommand = new SqlCommand("UPDATE ProvisionalElectionInPunjabResult SET Candidate2Count = Candidate2Count + 1", connection);
                }
                else
                {
                    TempData["Error"] = "Invalid candidate selection.";
                    return RedirectToAction("Vote");
                }

                updateCommand.ExecuteNonQuery();
            }

            Response.Cookies.Append("HasVoted", "true", new CookieOptions
            {
                Expires = DateTime.Now.AddDays(1),
                HttpOnly = true
            });

            TempData["Success"] = "Your vote has been recorded!";
            return RedirectToAction("vote");
        }

    }
}
