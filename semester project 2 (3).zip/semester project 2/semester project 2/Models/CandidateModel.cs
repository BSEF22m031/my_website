﻿namespace semester_project_2.Models
{
    public class CandidateModel
    {
        public string? Name { get; set; }
        public string? ImageUrl { get; set; }
        public string? Party { get; set; }
    }
}
