﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitlDAL;

namespace HospitalManagementSystem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Patient patient = new Patient
            {
                ID = 1,
                Name = "John Doe",
                Email = " johndoe @example.com",
                Disease = "Flu"
            };

            Menu menu = new Menu();
            string choice = menu.MenuFunction();


            switch (choice)
            {
                case "1":
                    patient.InsertPatient(Patient patient);
                    break;
                /*case "2":
                    UpdatePatient();
                    break;
                case "3":
                    DeletePatient();
                    break;
                case "4":
                    SearchPatientByName();
                    break;
                case "5":
                    ViewAllPatients();
                    break;
                case "6":
                    AddNewDoctor();
                    break;
                case "7":
                    UpdateDoctor();
                    break;
                case "8":
                    DeleteDoctor();
                    break;
                case "9":
                    SearchDoctorBySpecialization();
                    break;
                case "10":
                    ViewAllDoctors();
                    break;
                case "11":
                    BookAppointment();
                    break;
                case "12":
                    ViewAllAppointments();
                    break;
                case "13":
                    SearchAppointments();
                    break;
                case "14":
                    CancelAppointment();
                    break;
                case "15":
                    ViewDeletedRecordsHistory();
                    break;
                case "16":
                    exit = true;
                    Console.WriteLine("Exiting the application...");
                    break;*/
                default:
                    Console.WriteLine("Invalid option. Please try again.");
                    break;
            }

            Console.WriteLine();

        }
    }
    }
}
