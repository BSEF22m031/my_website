﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace HospitalDAL
{
    public class AppointmentOperation
    {
        public void InsertAppointment(Appointment appointment)
        {
            string conString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";
            SqlConnection conn = new SqlConnection(conString);

            try
            {
                conn.Open();
                string query = "INSERT INTO Appointment (appointmentId, patientId, doctorId, appointmentDate) VALUES (@AppointmentId, @PatientId, @DoctorId, @AppointmentDate);";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@AppointmentId", appointment.AppointmentId);
                cmd.Parameters.AddWithValue("@PatientId", appointment.PatientId);
                cmd.Parameters.AddWithValue("@DoctorId", appointment.DoctorId);
                cmd.Parameters.AddWithValue("@AppointmentDate", appointment.AppointmentDate);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            conn.Close();
        }

        public List<Appointment> GetAllAppointments()
        {
            List<Appointment> appointments = new List<Appointment>();
            string conString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";
            SqlConnection connection = new SqlConnection(conString);

            try
            {
                connection.Open();
                string query = $"SELECT * FROM Appointment";
                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Appointment appointment = new Appointment();
                    
                    
                    appointment.AppointmentId = Convert.ToInt32(dr["appointmentId"]);
                    appointment.PatientId = Convert.ToInt32(dr["patientId"]);
                    appointment.DoctorId = Convert.ToInt32(dr["doctorId"]);
                    appointment.AppointmentDate = Convert.ToDateTime(dr["appointmentDate"]);

                    appointments.Add(appointment);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            connection.Close();
            return appointments;
        }


        public void UpdateAppointment(Appointment appointment)
        {
            string conString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";
            SqlConnection connection = new SqlConnection(conString);

            try
            {
                connection.Open();
                string query = "UPDATE Appointment SET patientId = @PatientId, doctorId = @DoctorId, appointmentDate = @AppointmentDate WHERE appointmentId = @AppointmentId";
                SqlCommand cmd = new SqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@AppointmentId", appointment.AppointmentId);
                cmd.Parameters.AddWithValue("@PatientId", appointment.PatientId);
                cmd.Parameters.AddWithValue("@DoctorId", appointment.DoctorId);
                cmd.Parameters.AddWithValue("@AppointmentDate", appointment.AppointmentDate);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            connection.Close();
        }

        public void DeleteAppointment(int AppointmentId1)
        {
            string conString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";

            SqlConnection connection = new SqlConnection(conString);
            Appointment deletedAppointment = null;  

            try
            {
                connection.Open();

                string selectQuery = "SELECT * FROM Appointment WHERE appointmentId = @AppointmentId";
                SqlCommand selectCmd = new SqlCommand(selectQuery, connection);
                selectCmd.Parameters.AddWithValue("@AppointmentId", AppointmentId1);
                SqlDataReader reader = selectCmd.ExecuteReader();

                if (reader.Read())
                {
                    deletedAppointment = new Appointment
                    {
                        AppointmentId = Convert.ToInt32(reader["appointmentId"]),
                        PatientId = Convert.ToInt32(reader["patientId"]),
                        DoctorId = Convert.ToInt32(reader["doctorId"]),
                        AppointmentDate = Convert.ToDateTime(reader["appointmentDate"])
                    };
                }

                reader.Close();  

                if (deletedAppointment != null)
                {
                    string deleteQuery = "DELETE FROM Appointment WHERE appointmentId = @AppointmentId";
                    SqlCommand deleteCmd = new SqlCommand(deleteQuery, connection);
                    deleteCmd.Parameters.AddWithValue("@AppointmentId", AppointmentId1);
                    deleteCmd.ExecuteNonQuery();
                    History history = new History();    
                    history.AddDeletedAppointmentRecord(deletedAppointment);
                }
                else
                {
                    Console.WriteLine("Appointment not found for the given patient and doctor IDs.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();  
            }
        }

        

        public List<Appointment> SearchAppointmentsInDatabase(int doctorId, int patientId)
        {
            List<Appointment> appointments = new List<Appointment>();
            string conString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";

            using (SqlConnection connection = new SqlConnection(conString))
            {
                try
                {
                    connection.Open();

                    string query = "SELECT * FROM Appointment WHERE doctorId = @DoctorId AND patientId = @PatientId";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@DoctorId", doctorId);
                        cmd.Parameters.AddWithValue("@PatientId", patientId);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Appointment appointment = new Appointment
                                {
                                    AppointmentId = Convert.ToInt32(reader["AppointmentId"]),
                                    PatientId = Convert.ToInt32(reader["PatientId"]),
                                    DoctorId = Convert.ToInt32(reader["DoctorId"]),
                                    AppointmentDate = Convert.ToDateTime(reader["AppointmentDate"])
                                };

                                appointments.Add(appointment);
                            }
                        }
                    }

                    if (appointments.Count == 0)
                    {
                        Console.WriteLine("No appointments found for the provided doctor ID and patient ID.\n");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }
            }

            return appointments;
        }

    }
}
