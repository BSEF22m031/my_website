﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace HospitalDAL
{
    public class History
    {
        public void AddDeletedPatientRecord(Patient patient)
        {
            string conString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";
            SqlConnection conn = new SqlConnection(conString);
            try
            {
                conn.Open();
                string query = $"INSERT INTO DeletedPatientRecord(patientId, name, email, disease) VALUES ('{patient.PatientId}', '{patient.Name}', '{patient.Email}', '{patient.Disease}');";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            conn.Close();
        }
        public void AddDeletedDoctorRecord(Doctor doctor)
        {
            string conString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";
            SqlConnection conn = new SqlConnection(conString);
            try
            {
                conn.Open();
                string query = $"INSERT INTO DeletedDoctorRecord(doctorId, name, specialization) VALUES ('{doctor.DoctorId}', '{doctor.Name}', '{doctor.Specialization}');";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            conn.Close();
        }
        public void AddDeletedAppointmentRecord(Appointment appointment)
        {
            string conString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";
            SqlConnection conn = new SqlConnection(conString);

            try
            {
                conn.Open();
                string query = $"INSERT INTO DeletedAppointmentRecord(appointmentId, patientId, doctorId, appointmentDate) VALUES ('{appointment.AppointmentId}', '{appointment.PatientId}', '{appointment.DoctorId}', '{appointment.AppointmentDate}');";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            conn.Close();
        }
        public void ShowAllDeletedData()
        {
            string conString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";
            SqlConnection connection = new SqlConnection(conString);
            try
            {
                connection.Open();
                string query = $"SELECT * FROM DeletedPatientRecord";
                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    Console.WriteLine(Convert.ToInt32(dr["patientId"]));
                    Console.WriteLine(dr["name"].ToString());
                    Console.WriteLine(dr["email"].ToString());
                    Console.WriteLine(dr["disease"].ToString());
                    Console.WriteLine(((DateTime)dr["deletionDate"]).ToString("yyyy-MM-dd HH:mm"));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            connection.Close();
            string conString1 = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";
            SqlConnection connection1 = new SqlConnection(conString1);

            try
            {
                connection1.Open();
                string query2 = $"SELECT * FROM DeletedDoctorRecord";
                SqlCommand cmd = new SqlCommand(query2, connection1);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    Console.WriteLine(Convert.ToInt32(dr["doctorId"]));
                    Console.WriteLine(dr["name"].ToString());
                    Console.WriteLine(dr["specialization"].ToString());
                    Console.WriteLine(((DateTime)dr["deletionDate"]).ToString("yyyy-MM-dd HH:mm"));


                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            connection1.Close();
            string conString2 = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";
            SqlConnection connection2 = new SqlConnection(conString2);

            try
            {
                connection2.Open();
                string query3 = $"SELECT * FROM DeletedAppointmentRecord";
                SqlCommand cmd = new SqlCommand(query3, connection2);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {


                    Console.WriteLine(Convert.ToInt32(dr["appointmentId"]));
                    Console.WriteLine(Convert.ToInt32(dr["patientId"]));
                    Console.WriteLine(Convert.ToInt32(dr["doctorId"]));
                    Console.WriteLine(Convert.ToDateTime(dr["appointmentDate"]));
                    Console.WriteLine(((DateTime)dr["deletionDate"]).ToString("yyyy-MM-dd HH:mm"));

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            connection2.Close();

        }
    }
}
   
