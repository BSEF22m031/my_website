﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace HospitalDAL
{
    public class DoctorOperation
    {
        public void InsertDoctor(Doctor doctor)
        {
            string conString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";
            SqlConnection conn = new SqlConnection(conString);
            try
            {
                conn.Open();
                string query = "INSERT INTO Doctor (doctorId, name, specialization) VALUES (@DoctorId, @Name, @Specialization);";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@DoctorId", doctor.DoctorId);
                cmd.Parameters.AddWithValue("@Name", doctor.Name);
                cmd.Parameters.AddWithValue("@Specialization", doctor.Specialization);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            conn.Close();
        }

        public List<Doctor> GetAllDoctors()
        {
            List<Doctor> doctors = new List<Doctor>();
            string conString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";
            SqlConnection connection = new SqlConnection(conString);

            try
            {
                connection.Open();
                string query = $"SELECT * FROM Doctor";
                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    Doctor doctor = new Doctor();
                    doctor.DoctorId = Convert.ToInt32(dr["doctorId"]);
                    doctor.Name = dr["name"].ToString();
                    doctor.Specialization = dr["specialization"].ToString();

                    doctors.Add(doctor);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            connection.Close();

            return doctors;
        }


        public void UpdateDoctor(Doctor doctor)
        {
            string conString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";
            SqlConnection connection = new SqlConnection(conString);

            try
            {
                connection.Open();
                string query = "UPDATE Doctor SET name = @Name, specialization = @Specialization WHERE doctorId = @DoctorId";
                SqlCommand cmd = new SqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@DoctorId", doctor.DoctorId);
                cmd.Parameters.AddWithValue("@Name", doctor.Name);
                cmd.Parameters.AddWithValue("@Specialization", doctor.Specialization);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            connection.Close();
        }


        public void DeleteDoctor(int doctorId)
        {
            string conString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";

            SqlConnection connection = new SqlConnection(conString);
            Doctor deletedDoctor = null;  

            try
            {
                connection.Open();

                string selectQuery = "SELECT * FROM Doctor WHERE doctorId = @DoctorId";
                SqlCommand selectCmd = new SqlCommand(selectQuery, connection);
                selectCmd.Parameters.AddWithValue("@DoctorId", doctorId);
                SqlDataReader reader = selectCmd.ExecuteReader();

                if (reader.Read())
                {
                    deletedDoctor = new Doctor
                    {
                        DoctorId = Convert.ToInt32(reader["doctorId"]),
                        Name = reader["name"].ToString(),
                        Specialization = reader["specialization"].ToString()
                    };
                }

                reader.Close();  

                if (deletedDoctor != null)
                {
                    string deleteAppointmentsQuery = "DELETE FROM Appointment WHERE doctorId = @DoctorId";
                    SqlCommand deleteAppointmentsCmd = new SqlCommand(deleteAppointmentsQuery, connection);
                    deleteAppointmentsCmd.Parameters.AddWithValue("@DoctorId", doctorId);
                    deleteAppointmentsCmd.ExecuteNonQuery();

                    string deleteQuery = "DELETE FROM Doctor WHERE doctorId = @DoctorId";
                    SqlCommand deleteCmd = new SqlCommand(deleteQuery, connection);
                    deleteCmd.Parameters.AddWithValue("@DoctorId", doctorId);
                    deleteCmd.ExecuteNonQuery();
                    History history=new History();
                    history.AddDeletedDoctorRecord(deletedDoctor);
                }
                else
                {
                    Console.WriteLine("Doctor not found with the given ID.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();  
            }
        }

        

        public List<Doctor> SearchDoctorsInDatabase(string specialization)
        {
            List<Doctor> doctors = new List<Doctor>();
            string conString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";

            using (SqlConnection connection = new SqlConnection(conString))
            {
                try
                {
                    connection.Open();

                    string query = "SELECT * FROM Doctor WHERE Specialization = @Specialization";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@Specialization", specialization);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Doctor doctor = new Doctor
                                {
                                    DoctorId = Convert.ToInt32(reader["DoctorId"]),
                                    Name = reader["Name"].ToString(),
                                    Specialization = reader["Specialization"].ToString()
                                };

                                doctors.Add(doctor);
                            }
                        }
                    }

                    if (doctors.Count == 0)
                    {
                        Console.WriteLine("No data found for the provided specialization.\n");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }
            }

            return doctors;
        }


    }
}
