﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using static System.Net.Mime.MediaTypeNames;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace HospitalDAL
{
    public class PatientOperation
    {
        History history=new History();
        public void InsertPatient(Patient patient)
        {
            string conString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";
            SqlConnection conn = new SqlConnection(conString);
            try
            {
                conn.Open();
                string query = "INSERT INTO Patient (patientId, name, email, disease) VALUES (@PatientId, @Name, @Email, @Disease);";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@PatientId", patient.PatientId);
                cmd.Parameters.AddWithValue("@Name", patient.Name);
                cmd.Parameters.AddWithValue("@Email", patient.Email);
                cmd.Parameters.AddWithValue("@Disease", patient.Disease);

               
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            conn.Close();
        }
        public List<Patient> GetAllPatients()
        {
            List<Patient> patients = new List<Patient>();
            string conString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";
            SqlConnection connection = new SqlConnection(conString);

            try
            {
                connection.Open();
                string query = $"SELECT * FROM Patient";
                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    Patient patient = new Patient();
                    patient.PatientId = Convert.ToInt32(dr["patientId"]);
                    patient.Name = dr["name"].ToString();
                    patient.Email = dr["email"].ToString();
                    patient.Disease = dr["disease"].ToString();

                    patients.Add(patient);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


            connection.Close();


            return patients;
        }

        public void UpdatePatient(Patient patient)
        {
            string conString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";
            SqlConnection connection = new SqlConnection(conString);

            try
            {
                connection.Open();
                string query = "UPDATE Patient SET name = @Name, email = @Email, disease = @Disease WHERE patientId = @PatientId";
                SqlCommand cmd = new SqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@PatientId", patient.PatientId);
                cmd.Parameters.AddWithValue("@Name", patient.Name);
                cmd.Parameters.AddWithValue("@Email", patient.Email);
                cmd.Parameters.AddWithValue("@Disease", patient.Disease);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            connection.Close();

        }

        public void DeletePatient(int patientId)
        {
            string conString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";

            SqlConnection connection = new SqlConnection(conString);
            Patient deletedPatient = null;  

            try
            {
                connection.Open();

                string selectQuery = "SELECT * FROM Patient WHERE patientId = @PatientId";
                SqlCommand selectCmd = new SqlCommand(selectQuery, connection);
                selectCmd.Parameters.AddWithValue("@PatientId", patientId);
                SqlDataReader reader = selectCmd.ExecuteReader();

                if (reader.Read())
                {
                    deletedPatient = new Patient
                    {
                        PatientId = Convert.ToInt32(reader["patientId"]),
                        Name = reader["name"].ToString(),
                        Email = reader["email"].ToString(),
                        Disease = reader["disease"].ToString()
                    };
                }

                reader.Close();  

                
                if (deletedPatient != null)
                {
                    string deleteAppointmentsQuery = "DELETE FROM Appointment WHERE patientId = @PatientId";
                    SqlCommand deleteAppointmentsCmd = new SqlCommand(deleteAppointmentsQuery, connection);
                    deleteAppointmentsCmd.Parameters.AddWithValue("@PatientId", patientId);
                    deleteAppointmentsCmd.ExecuteNonQuery();

                    string deleteQuery = "DELETE FROM Patient WHERE patientId = @PatientId";
                    SqlCommand deleteCmd = new SqlCommand(deleteQuery, connection);
                    deleteCmd.Parameters.AddWithValue("@PatientId", patientId);
                    deleteCmd.ExecuteNonQuery();

                    history.AddDeletedPatientRecord(deletedPatient);
                }
                else
                {
                    Console.WriteLine("Patient not found with the given ID.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            
                connection.Close();
            
        }

        public List<Patient> SearchPatientsInDatabase(string name)
        {
            List<Patient> patients = new List<Patient>();
            string conString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = HospitalManagementSystem; Integrated Security = True;";

            using (SqlConnection connection = new SqlConnection(conString))
            {
                try
                {
                    connection.Open();

                    string query = "SELECT * FROM Patient WHERE Name = @Name";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@Name", name);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Patient patient = new Patient
                                {
                                    PatientId = Convert.ToInt32(reader["PatientId"]),
                                    Name = reader["Name"].ToString(),
                                    Email = reader["Email"].ToString(),
                                    Disease = reader["Disease"].ToString()
                                };

                                patients.Add(patient);
                            }
                        }
                    }

                    if (patients.Count == 0)
                    {
                        Console.WriteLine("No data found for the provided name.\n");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }
            }

            return patients;
        }

    }
}
