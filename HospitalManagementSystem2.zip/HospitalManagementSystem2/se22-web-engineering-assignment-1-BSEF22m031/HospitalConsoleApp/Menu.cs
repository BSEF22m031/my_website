﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalConsoleApp
{
    internal class Menu
    {
        public string MenuFunction()
        {
            Console.WriteLine("Menu Options:");
            Console.WriteLine("1. Add a new patient");
            Console.WriteLine("2. Update a patient");
            Console.WriteLine("3. Delete a patient (and save deleted record to history)");
            Console.WriteLine("4. Search for patients by name");
            Console.WriteLine("5. View all patients");
            Console.WriteLine("6. Add a new doctor");
            Console.WriteLine("7. Update a doctor");
            Console.WriteLine("8. Delete a doctor (and save deleted record to history)");
            Console.WriteLine("9. Search for doctors by specialization");
            Console.WriteLine("10. View all doctors");
            Console.WriteLine("11. Book an appointment");
            Console.WriteLine("12. View all appointments");
            Console.WriteLine("13. Search appointments by doctor or patient");
            Console.WriteLine("14. Cancel an appointment (and save deleted appointment to history)");
            Console.WriteLine("15. View history of deleted records (patients, doctors, or appointments)");
            Console.WriteLine("16. Exit the application");
            Console.Write("Select an option: ");
            string choice = Console.ReadLine();
            return choice;
        }
    }
}
