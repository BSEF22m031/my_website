﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalConsoleApp;
using HospitalDAL;
using static System.Net.Mime.MediaTypeNames;

namespace HospitalManagementSystem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            PatientOperation patientOperation = new PatientOperation();
            DoctorOperation doctorOperation = new DoctorOperation();
            AppointmentOperation appointmentOperation = new AppointmentOperation();
            History history = new History();
            Menu menu = new Menu();
            string choice = menu.MenuFunction();

            


            switch (choice)
            {
                case "1":

                    Patient patient = new Patient();
                    Console.WriteLine("Enter Patient ID: ");
                    patient.PatientId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Patient Name: ");
                    patient.Name = Console.ReadLine();
                    Console.WriteLine("Enter Patient Email: ");
                    patient.Email = Console.ReadLine();
                    string email = patient.Email;
                    bool correct=false;
                    for (int i = 0; i < email.Length; i++)
                    {
                        if (email[i] == '@')
                        {

                            string subString = email.Substring(i, email.Length - i);
                            if(subString=="@gmail.com")
                            {
                                correct = true;
                            }

                        }
                    }
                    if(correct==false)
                    {
                        Console.WriteLine("incorrect email format\n");
                        break;
                    }
                    Console.WriteLine("Enter Patient Disease: ");
                    patient.Disease = Console.ReadLine();
                    patientOperation.InsertPatient(patient);
                    break;
                case "2":
                    Patient patient2 = new Patient();
                    Console.WriteLine("Enter Patient ID: ");
                    patient2.PatientId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Patient Name: ");
                    patient2.Name = Console.ReadLine();
                    Console.WriteLine("Enter Patient Email: ");
                    patient2.Email = Console.ReadLine();
                    string Email = patient2.Email;
                    bool correct1 = false;
                    for (int i = 0; i < Email.Length; i++)
                    {
                        if (Email[i] == '@')
                        {

                            string subString = Email.Substring(i, Email.Length - i);
                            if (subString == "@gmail.com")
                            {
                                correct = true;
                            }

                        }
                    }
                    if (correct1 == false)
                    {
                        Console.WriteLine("incorrect email format\n");
                        break;
                    }
                    Console.WriteLine("Enter Patient Disease: ");
                    patient2.Disease = Console.ReadLine();
                    patientOperation.UpdatePatient(patient2);
                    break;
                case "3":
                    int deletepatientId;
                    Console.WriteLine("Enter Patient ID: ");
                    deletepatientId = Convert.ToInt32(Console.ReadLine());
                    patientOperation.DeletePatient(deletepatientId);
                    break;
                case "4":
                    string name;
                    List<Patient> patients = new List<Patient>();
                    Console.WriteLine("enter the name to search\n");
                    name = Console.ReadLine();
                    patients = patientOperation.SearchPatientsInDatabase(name);
                    for (int i = 0; i < patients.Count; i++)
                    {
                        Console.WriteLine("Patient ID: " + patients[i].PatientId);
                        Console.WriteLine("Name: " + patients[i].Name);
                        Console.WriteLine("Email: " + patients[i].Email);
                        Console.WriteLine("Disease: " + patients[i].Disease);
                    }
                    break;
                case "5":
                    List<Patient> patients1 = new List<Patient>();
                    patients1 = patientOperation.GetAllPatients();
                    for (int i = 0; i < patients1.Count; i++)
                    {
                        Console.WriteLine("Patient ID: " + patients1[i].PatientId);
                        Console.WriteLine("Name: " + patients1[i].Name);
                        Console.WriteLine("Email: " + patients1[i].Email);
                        Console.WriteLine("Disease: " + patients1[i].Disease);
                    }
                    break;
                case "6":
                    Doctor doctor = new Doctor();

                    Console.WriteLine("Enter Doctor ID: ");
                    doctor.DoctorId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Doctor Name: ");
                    doctor.Name = Console.ReadLine();
                    Console.WriteLine("Enter Doctor Specialization: ");
                    doctor.Specialization = Console.ReadLine();
                    doctorOperation.InsertDoctor(doctor);
                    break;
                case "7":
                    Doctor Updatedoctor = new Doctor();

                    Console.WriteLine("Enter Doctor ID: ");
                    Updatedoctor.DoctorId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Doctor Name: ");
                    Updatedoctor.Name = Console.ReadLine();
                    Console.WriteLine("Enter Doctor Specialization: ");
                    Updatedoctor.Specialization = Console.ReadLine();
                    doctorOperation.UpdateDoctor(Updatedoctor);
                    break;
                case "8":
                    int deleteDoctorId;
                    Console.WriteLine("Enter Doctor ID: ");
                    deleteDoctorId = Convert.ToInt32(Console.ReadLine());
                   
                    doctorOperation.DeleteDoctor(deleteDoctorId);
                    break;
                case "9":
                    string name2;
                    List<Doctor> doctors = new List<Doctor>();
                    Console.WriteLine("enter the name to search\n");
                    name2 = Console.ReadLine();
                    doctors=doctorOperation.SearchDoctorsInDatabase(name2);
                    for (int i = 0; i < doctors.Count; i++)
                    {
                        Console.WriteLine("Doctor ID: " + doctors[i].DoctorId);
                        Console.WriteLine("Name: " + doctors[i].Name);
                        Console.WriteLine("Specialization: " + doctors[i].Specialization);
                        Console.WriteLine();
                    }
                    break;
                case "10":
                    List<Doctor> doctors1 = new List<Doctor>();

                    doctors1 = doctorOperation.GetAllDoctors();
                    for (int i = 0; i < doctors1.Count; i++)
                    {
                        Console.WriteLine("Doctor ID: " + doctors1[i].DoctorId);
                        Console.WriteLine("Name: " + doctors1[i].Name);
                        Console.WriteLine("Specialization: " + doctors1[i].Specialization);
                        Console.WriteLine();
                    }
                    break;
                case "11":
                    Appointment appointment = new Appointment();
                    Console.WriteLine("Enter Appointment ID: ");
                    appointment.AppointmentId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Patient ID: ");
                    appointment.PatientId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Doctor ID: ");
                    appointment.DoctorId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Appointment Date (yyyy-MM-dd HH:mm): ");
                    appointment.AppointmentDate = Convert.ToDateTime(Console.ReadLine());
                    appointmentOperation.InsertAppointment(appointment);
                    break;
                case "12":
                    List<Appointment> appointments = new List<Appointment>();
                    appointments=appointmentOperation.GetAllAppointments();
                    for (int i = 0; i < appointments.Count; i++)
                    {
                        Console.WriteLine("Appointment ID: " + appointments[i].AppointmentId);
                        Console.WriteLine("Patient ID: " + appointments[i].PatientId);
                        Console.WriteLine("Doctor ID: " + appointments[i].DoctorId);
                        Console.WriteLine("Appointment Date: " + appointments[i].AppointmentDate.ToString("yyyy-MM-dd HH:mm"));
                    }

                    break;
                case "13":
                    Console.Write("Enter Doctor ID: ");
                    int doctorId = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter Patient ID: ");
                    int patientId = Convert.ToInt32(Console.ReadLine());
                    List<Appointment> appointments1 = appointmentOperation.SearchAppointmentsInDatabase(doctorId, patientId);
                    for (int i = 0; i < appointments1.Count; i++)
                    {
                        Console.WriteLine("Appointment ID: " + appointments1[i].AppointmentId);
                        Console.WriteLine("Patient ID: " + appointments1[i].PatientId);
                        Console.WriteLine("Doctor ID: " + appointments1[i].DoctorId);
                        Console.WriteLine("Appointment Date: " + appointments1[i].AppointmentDate.ToString("yyyy-MM-dd HH:mm"));
                        Console.WriteLine();
                    }
                    break;
                case "14":
                    int deleteAppointmentId;
                    Console.WriteLine("Enter Appointment ID: ");
                    deleteAppointmentId = Convert.ToInt32(Console.ReadLine());
                    
                    
                    appointmentOperation.DeleteAppointment(deleteAppointmentId);
                    break;
                case "15":
                    history.ShowAllDeletedData();
                    break;
                case "16":
                    Console.WriteLine("Exiting the application...");
                    break;
                default:
                    Console.WriteLine("Invalid option. Please try again.");
                    break;
            }

            Console.WriteLine();

        }
    }
}
