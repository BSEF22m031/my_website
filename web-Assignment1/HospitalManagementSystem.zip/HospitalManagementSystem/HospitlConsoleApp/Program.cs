﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitlDAL;

namespace HospitalConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            PatientOperation patientOperation = new PatientOperation();
            DoctorOperation doctorOperation = new DoctorOperation();
            AppointmentOperation appointmentOperation = new AppointmentOperation();
            History history = new History();
            Menu menu = new Menu();
            string choice = menu.MenuFunction();

            switch (choice)
            {
                case "1":

                    Patient patient = new Patient();
                    Console.WriteLine("Enter Patient ID: ");
                    patient.PatientId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Patient Name: ");
                    patient.Name = Console.ReadLine();
                    Console.WriteLine("Enter Patient Email: ");
                    patient.Email = Console.ReadLine();
                    Console.WriteLine("Enter Patient Disease: ");
                    patient.Disease = Console.ReadLine();
                    patientOperation.InsertPatient(patient);
                    break;
                case "2":
                    Patient patient2 = new Patient();
                    Console.WriteLine("Enter Patient ID: ");
                    patient2.PatientId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Patient Name: ");
                    patient2.Name = Console.ReadLine();
                    Console.WriteLine("Enter Patient Email: ");
                    patient2.Email = Console.ReadLine();
                    Console.WriteLine("Enter Patient Disease: ");
                    patient2.Disease = Console.ReadLine();
                    patientOperation.UpdatePatientInDatabase(patient2);
                    break;
                case "3":
                    int patientiddelete;
                    Console.WriteLine("Enter Patient ID: ");
                    patientiddelete = Convert.ToInt32(Console.ReadLine());
                    
                    patientOperation.DeletePatientFromDatabase(patientiddelete);
                    break;
                case "4":
                    string name;
                    List<Patient> patients = new List<Patient>();
                    Console.WriteLine("enter the name to search\n");
                    name = Console.ReadLine();
                    patients = patientOperation.SearchPatientsInDatabase(name);
                    for (int i = 0; i < patients.Count; i++)
                    {
                        Console.WriteLine("Patient ID: " + patients[i].PatientId);
                        Console.WriteLine("Name: " + patients[i].Name);
                        Console.WriteLine("Email: " + patients[i].Email);
                        Console.WriteLine("Disease: " + patients[i].Disease);
                    }
                    break;
                case "5":
                    List<Patient> patients1 = new List<Patient>();
                    patients1 = patientOperation.GetAllPatientsFromDatabase();
                    for (int i = 0; i < patients1.Count; i++)
                    {
                        Console.WriteLine("Patient ID: " + patients1[i].PatientId);
                        Console.WriteLine("Name: " + patients1[i].Name);
                        Console.WriteLine("Email: " + patients1[i].Email);
                        Console.WriteLine("Disease: " + patients1[i].Disease);
                    }
                    break;
                case "6":
                    Doctor doctor = new Doctor();

                    Console.WriteLine("Enter Doctor ID: ");
                    doctor.DoctorId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Doctor Name: ");
                    doctor.Name = Console.ReadLine();
                    Console.WriteLine("Enter Doctor Specialization: ");
                    doctor.Specialization = Console.ReadLine();
                    doctorOperation.InsertDoctor(doctor);
                    break;
                case "7":
                    Doctor Updatedoctor = new Doctor();

                    Console.WriteLine("Enter Doctor ID: ");
                    Updatedoctor.DoctorId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Doctor Name: ");
                    Updatedoctor.Name = Console.ReadLine();
                    Console.WriteLine("Enter Doctor Specialization: ");
                    Updatedoctor.Specialization = Console.ReadLine();
                    doctorOperation.UpdateDoctorInDatabase(Updatedoctor);
                    break;
                case "8":
                    Doctor deletedoctor = new Doctor();
                    int deletedDoctorId;
                    Console.WriteLine("Enter Doctor ID: ");
                    deletedDoctorId = Convert.ToInt32(Console.ReadLine());
                    
                    doctorOperation.DeleteDoctorFromDatabase(deletedDoctorId);
                    break;
                case "9":
                    string name2;
                    List<Doctor> doctors = new List<Doctor>();
                    Console.WriteLine("enter the name to search\n");
                    name2 = Console.ReadLine();
                    doctors = doctorOperation.SearchDoctorsInDatabase(name2);
                    for (int i = 0; i < doctors.Count; i++)
                    {
                        Console.WriteLine("Doctor ID: " + doctors[i].DoctorId);
                        Console.WriteLine("Name: " + doctors[i].Name);
                        Console.WriteLine("Specialization: " + doctors[i].Specialization);
                        Console.WriteLine();
                    }
                    break;
                case "10":
                    List<Doctor> doctors1 = new List<Doctor>();

                    doctors1 = doctorOperation.GetAllDoctorsFromDatabase();
                    for (int i = 0; i < doctors1.Count; i++)
                    {
                        Console.WriteLine("Doctor ID: " + doctors1[i].DoctorId);
                        Console.WriteLine("Name: " + doctors1[i].Name);
                        Console.WriteLine("Specialization: " + doctors1[i].Specialization);
                        Console.WriteLine();
                    }
                    break;
                case "11":
                    Appointment appointment = new Appointment();
                    Console.WriteLine("Enter Appointment ID: ");
                    appointment.AppointmentId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Patient ID: ");
                    appointment.PatientId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Doctor ID: ");
                    appointment.DoctorId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Appointment Date (yyyy-MM-dd HH:mm): ");
                    appointment.AppointmentDate = Convert.ToDateTime(Console.ReadLine());
                    appointmentOperation.InsertAppointment(appointment);
                    break;
                case "12":
                    List<Appointment> appointments = new List<Appointment>();
                    appointments = appointmentOperation.GetAllAppointmentsFromDatabase();
                    for (int i = 0; i < appointments.Count; i++)
                    {
                        Console.WriteLine("Appointment ID: " + appointments[i].AppointmentId);
                        Console.WriteLine("Patient ID: " + appointments[i].PatientId);
                        Console.WriteLine("Doctor ID: " + appointments[i].DoctorId);
                        Console.WriteLine("Appointment Date: " + appointments[i].AppointmentDate.ToString("yyyy-MM-dd HH:mm"));
                    }

                    break;
                case "13":
                    Console.Write("Enter Doctor ID: ");
                    int doctorId = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter Patient ID: ");
                    int patientId = Convert.ToInt32(Console.ReadLine());
                    List<Appointment> appointments1 = appointmentOperation.SearchAppointmentsInDatabase(doctorId, patientId);
                    for (int i = 0; i < appointments1.Count; i++)
                    {
                        Console.WriteLine("Appointment ID: " + appointments1[i].AppointmentId);
                        Console.WriteLine("Patient ID: " + appointments1[i].PatientId);
                        Console.WriteLine("Doctor ID: " + appointments1[i].DoctorId);
                        Console.WriteLine("Appointment Date: " + appointments1[i].AppointmentDate.ToString("yyyy-MM-dd HH:mm"));
                        Console.WriteLine();
                    }
                    break;
                case "14":
                    int deletedAppointmentId;
                    Console.WriteLine("Enter Appointment ID: ");
                    deletedAppointmentId = Convert.ToInt32(Console.ReadLine());
                    
                    appointmentOperation.DeleteAppointmentFromDatabase(deletedAppointmentId);
                    break;
                case "15":
                     history.ShowAllDeletedData();
                    break;
                case "16":
                    Console.WriteLine("Exiting the application...");
                    break;
                default:
                    Console.WriteLine("Invalid option. Please try again.");
                    break;
            }

            Console.WriteLine();

        }
    }
}
        