﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace HospitlDAL
{
    public class History
    {
        public void AddDeletedPatientRecord(Patient patient)
        {
            using (StreamWriter DeletedPatientfileWriter = new StreamWriter("DeletedPatient.txt", true))
            {
                string data = JsonSerializer.Serialize(patient);
                data = data + DateTime.Now;
                DeletedPatientfileWriter.WriteLine(data);
            }
        }
        public void AddDeletedDoctorRecord(Doctor doctor)
        {
            using (StreamWriter deletedDoctorFileWriter = new StreamWriter("DeletedDoctor.txt", true))
            {
                string data = JsonSerializer.Serialize(doctor);
                data = data + DateTime.Now;
                deletedDoctorFileWriter.WriteLine(data);
            }
        }
        public void AddDeletedAppointmentRecord(Appointment appointment)
        {
            using (StreamWriter deletedAppointmentFileWriter = new StreamWriter("DeletedAppointment.txt", true))
            {
                string data = JsonSerializer.Serialize(appointment);
                data = data + DateTime.Now;
                deletedAppointmentFileWriter.WriteLine(data);
            }
        }
        public void ShowAllDeletedData()
        {
            if (File.Exists("DeletedPatient.txt"))
            {
                using (StreamReader reader = new StreamReader("DeletedPatient.txt"))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        Patient patient = JsonSerializer.Deserialize<Patient>(line);
                        Console.WriteLine("Patient ID: " + patient.PatientId);
                        Console.WriteLine("Name: " + patient.Name);
                        Console.WriteLine("Email: " + patient.Email);
                        Console.WriteLine("Disease: " + patient.Disease);
                        Console.WriteLine();
                    }
                }
            }
            else
            {
                Console.WriteLine("No deleted patient data found.");
            }
            if (File.Exists("DeletedDoctor.txt"))
            {
                using (StreamReader reader = new StreamReader("DeletedDoctor.txt"))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        Doctor doctor1 = JsonSerializer.Deserialize<Doctor>(line);
                        Console.WriteLine("Doctor ID: " + doctor1.DoctorId);
                        Console.WriteLine("Name: " + doctor1.Name);
                        Console.WriteLine("Specialization: " + doctor1.Specialization);
                    }
                }
            }
            else
            {
                Console.WriteLine("No deleted doctor data found.");
            }
            if (File.Exists("DeletedAppointment.txt"))
            {
                using (StreamReader reader = new StreamReader("DeletedAppointment.txt"))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        Appointment appointment = JsonSerializer.Deserialize<Appointment>(line);
                        Console.WriteLine("Appointment ID: " + appointment.AppointmentId);
                        Console.WriteLine("Patient ID: " + appointment.PatientId);
                        Console.WriteLine("Doctor ID: " + appointment.DoctorId);
                        Console.WriteLine("Appointment Date: " + appointment.AppointmentDate.ToString("yyyy-MM-dd HH:mm"));
                        Console.WriteLine();  
                    }
                }
            }
            else
            {
                Console.WriteLine("No deleted appointment data found.");
            }

        }
    }
}
