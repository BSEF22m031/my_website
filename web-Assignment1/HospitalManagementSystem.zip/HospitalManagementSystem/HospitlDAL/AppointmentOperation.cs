﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace HospitlDAL
{
    
    public class AppointmentOperation
    {
        public void InsertAppointment(Appointment appointment)
        {
            StreamWriter AppointmentfileWriter = new StreamWriter("Appointments.txt", true);
            string data = JsonSerializer.Serialize(appointment);
            AppointmentfileWriter.WriteLine(data);
            AppointmentfileWriter.Close();

        }
        public List<Appointment> GetAllAppointmentsFromDatabase()
        {
            List<Appointment> appointments = new List<Appointment>();
            if (File.Exists("Appointments.txt"))
            {
                using (StreamReader reader = new StreamReader("Appointments.txt"))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        Appointment appointment1 = JsonSerializer.Deserialize<Appointment>(line);
                        appointments.Add(appointment1);
                    }
                }
            }
            return appointments;
        }

        public void UpdateAppointmentInDatabase(Appointment appointment)
        {
            if (File.Exists("Appointments.txt"))
            {
                using (StreamReader reader = new StreamReader("Appointments.txt"))
                {
                    bool updated = false;
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        Appointment appointment1 = JsonSerializer.Deserialize<Appointment>(line);

                        if (appointment1.AppointmentId == appointment.AppointmentId)
                        {
                            using (StreamWriter appointmentFileWriter = new StreamWriter("NewAppointments.txt", true))
                            {
                                string data = JsonSerializer.Serialize(appointment);
                                appointmentFileWriter.WriteLine(data);
                            }
                            updated = true;
                        }
                        else
                        {
                            using (StreamWriter appointmentFileWriter = new StreamWriter("NewAppointments.txt", true))
                            {
                                appointmentFileWriter.WriteLine(line);
                            }
                        }
                    }

                    File.Delete("Appointments.txt");
                    File.Move("NewAppointments.txt", "Appointments.txt");

                    if (updated)
                    {
                        Console.WriteLine("Appointment record updated successfully.");
                    }
                    else
                    {
                        Console.WriteLine("Appointment not found for update.");
                    }
                }
            }
            else
            {
                Console.WriteLine("Appointments.txt file does not exist.");
            }
        }

        public void DeleteAppointmentFromDatabase(int appointmentId)
        {
            if (File.Exists("Appointments.txt"))
            {
                using (StreamReader reader = new StreamReader("Appointments.txt"))
                {
                    bool deleted = false;
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        Appointment appointment1 = JsonSerializer.Deserialize<Appointment>(line);

                        if (appointment1.AppointmentId == appointmentId)
                        {
                            History history = new History();
                            history.AddDeletedAppointmentRecord(appointment1);
                            deleted = true;
                        }
                        else
                        {
                            using (StreamWriter appointmentFileWriter = new StreamWriter("NewAppointments.txt", true))
                            {
                                appointmentFileWriter.WriteLine(line);
                            }
                        }
                    }

                    File.Delete("Appointments.txt");
                    File.Move("NewAppointments.txt", "Appointments.txt");

                    if (deleted)
                    {
                        Console.WriteLine("Appointment record deleted successfully.");
                    }
                    else
                    {
                        Console.WriteLine("Appointment not found for deletion.");
                    }
                }
            }
            else
            {
                Console.WriteLine("Appointments.txt file does not exist.");
            }
        }
        public List<Appointment> SearchAppointmentsInDatabase(int doctorId, int patientId)
        {
            List<Appointment> appointments = new List<Appointment>();

            if (File.Exists("Appointments.txt"))
            {
                using (StreamReader reader = new StreamReader("Appointments.txt"))
                {
                    bool searched = false;
                    string line;

                    while ((line = reader.ReadLine()) != null)
                    {
                        Appointment appointment1 = JsonSerializer.Deserialize<Appointment>(line);
                        if (appointment1.DoctorId == doctorId && appointment1.PatientId == patientId)
                        {
                            appointments.Add(appointment1);
                            searched = true;
                        }
                    }

                    if (!searched)
                    {
                        Console.WriteLine("No appointment data found with the given doctor's id or patient id.\n");
                    }
                }
            }
            else
            {
                Console.WriteLine("Appointments.txt file does not exist.\n");
            }

            return appointments;
        }
    }
}

