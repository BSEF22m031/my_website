﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace HospitlDAL
{
    public class PatientOperation
    {
        public void InsertPatient(Patient patient)
        {
            if (File.Exists("Patient.txt"))
            {
                StreamWriter PatientfileWriter = new StreamWriter("Patient.txt", true);
                string data = JsonSerializer.Serialize(patient);
                PatientfileWriter.WriteLine(data);
            }
            else
            {
                StreamWriter PatientfileWriter = new StreamWriter("Patient.txt");
                string data = JsonSerializer.Serialize(patient);
                PatientfileWriter.WriteLine(data);
            }
        }   
        public List<Patient> GetAllPatientsFromDatabase()
        {
            List<Patient> patients = new List<Patient>();
            if (File.Exists("Patient.txt"))
            {
                using (StreamReader reader = new StreamReader("Patient.txt"))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        Patient patient1 = JsonSerializer.Deserialize<Patient>(line);
                        patients.Add(patient1);
                    }
                }
            }
            return patients;
        }
        public void UpdatePatientInDatabase(Patient patient)
        {
            if (File.Exists("Patient.txt"))
            {
                using (StreamReader reader = new StreamReader("Patient.txt"))
                {
                    bool updated = false;
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        Patient patient1 = JsonSerializer.Deserialize<Patient>(line);
                        if (patient1.PatientId == patient.PatientId)
                        {
                            StreamWriter PatientfileWriter1 = new StreamWriter("NewPatient.txt", true);
                            string data = JsonSerializer.Serialize(patient);
                            PatientfileWriter1.WriteLine(data);
                            updated = true;
                        }
                        else
                        {
                            StreamWriter PatientfileWriter1 = new StreamWriter("NewPatient.txt", true);
                            PatientfileWriter1.WriteLine(line);
                        }

                    }
                    File.Delete("Patient.txt");
                    File.Move("NewPatient.txt", "Patient.txt");
                    if (updated)
                    {
                        Console.WriteLine("updated successfuly\n");
                    }
                    else
                    {
                        Console.WriteLine("Not updated\n");
                    }
                }
            }
            else
            {
                Console.WriteLine("file not exist\n");
            }
        }

        public void DeletePatientFromDatabase(int patientId)
        {
            if (File.Exists("Patient.txt"))
            {
                using (StreamReader reader = new StreamReader("Patient.txt"))
                {
                    bool deleted = false;
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        Patient patient1 = JsonSerializer.Deserialize<Patient>(line);
                        if (patient1.PatientId == patientId)
                        {
                            History history = new History();
                            history.AddDeletedPatientRecord(patient1);

                            deleted = true;
                        }
                        else
                        {
                            StreamWriter PatientfileWriter1 = new StreamWriter("NewPatient.txt", true);
                            PatientfileWriter1.WriteLine(line);
                        }

                    }
                    //File.Delete("Patient.txt");
                    File.Move("NewPatient.txt", "Patient.txt");
                    if (deleted)
                    {
                        Console.WriteLine("deleted successfuly\n");
                    }
                    else
                    {
                        Console.WriteLine("Not deleted\n");
                    }
                }
            }
            else
            {
                Console.WriteLine("file not exist\n");
            }
        }
        public List<Patient> SearchPatientsInDatabase(string name)
        {
            List<Patient> patients = new List<Patient>();
            if (File.Exists("Patient.txt"))
            {
                using (StreamReader reader = new StreamReader("Patient.txt"))
                {
                    bool searched = false;
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        Patient patient1 = JsonSerializer.Deserialize<Patient>(line);
                        if (patient1.Name == name)
                        {
                            patients.Add(patient1);
                            searched = true;
                        }
                    }
                    if (!searched)
                    {
                        Console.WriteLine("no data found\n");
                    }
                }
            }
            else
            {
                Console.WriteLine("file not exist\n");
            }
            return patients;
        }
    }
}
