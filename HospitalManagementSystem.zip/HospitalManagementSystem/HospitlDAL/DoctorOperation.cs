﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace HospitlDAL
{
    public class DoctorOperation
    {
        public void InsertDoctor(Doctor doctor)
        {

            StreamWriter DoctorfileWriter = new StreamWriter("Doctors.txt", true);
            string data = JsonSerializer.Serialize(doctor);
            DoctorfileWriter.WriteLine(data);

        }
        public List<Doctor> GetAllDoctorsFromDatabase()
        {
            List<Doctor> doctors = new List<Doctor>();
            if (File.Exists("Doctors.txt"))
            {
                using (StreamReader reader = new StreamReader("Doctors.txt"))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null) 
                    {
                        Doctor doctor1 = JsonSerializer.Deserialize<Doctor>(line);
                        doctors.Add(doctor1);
                    }
                }
            }
            return doctors;

        }

        public void UpdateDoctorInDatabase(Doctor doctor)
        {
            if (File.Exists("Doctor.txt"))
            {
                using (StreamReader reader = new StreamReader("Doctor.txt"))
                {
                    bool updated = false;
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        Doctor doctor1 = JsonSerializer.Deserialize<Doctor>(line);

                        if (doctor1.DoctorId == doctor.DoctorId)
                        {
                            using (StreamWriter doctorFileWriter = new StreamWriter("NewDoctor.txt", true))
                            {
                                string data = JsonSerializer.Serialize(doctor);
                                doctorFileWriter.WriteLine(data);
                            }
                            updated = true;
                        }
                        else
                        {
                            using (StreamWriter doctorFileWriter = new StreamWriter("NewDoctor.txt", true))
                            {
                                doctorFileWriter.WriteLine(line);
                            }
                        }
                    }
                    File.Delete("Doctor.txt");
                    File.Move("NewDoctor.txt", "Doctor.txt");

                    if (updated)
                    {
                        Console.WriteLine("Doctor record updated successfully.");
                    }
                    else
                    {
                        Console.WriteLine("Doctor not found for update.");
                    }
                }


            }
            else
            {
                Console.WriteLine("Doctor.txt file does not exist.");
            }
        }


        public void DeleteDoctorFromDatabase(int doctorId)
        {
            if (File.Exists("Doctor.txt"))
            {
                using (StreamReader reader = new StreamReader("Doctor.txt"))
                {
                    bool deleted = false;
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        Doctor doctor1 = JsonSerializer.Deserialize<Doctor>(line);

                        if (doctor1.DoctorId == doctorId)
                        {
                            History history = new History();
                            history.AddDeletedDoctorRecord(doctor1);
                            deleted = true;

                        }
                        else
                        {
                            using (StreamWriter doctorFileWriter = new StreamWriter("NewDoctor.txt", true))
                            {
                                doctorFileWriter.WriteLine(line);
                            }
                        }
                    }
                    File.Delete("Doctor.txt");
                    File.Move("NewDoctor.txt", "Doctor.txt");

                    if (deleted)
                    {
                        Console.WriteLine("Doctor record deleted successfully.");
                    }
                    else
                    {
                        Console.WriteLine("Doctor not found for deletion.");
                    }
                }


            }
            else
            {
                Console.WriteLine("Doctor.txt file does not exist.");
            }
        }
        public List<Doctor> SearchDoctorsInDatabase(string specialization)
        {
            List<Doctor> doctors = new List<Doctor>();

            if (File.Exists("Doctor.txt"))
            {
                using (StreamReader reader = new StreamReader("Doctor.txt"))
                {
                    bool searched = false;
                    string line;

                    while ((line = reader.ReadLine()) != null)
                    {
                        Doctor doctor1 = JsonSerializer.Deserialize<Doctor>(line);

                        if (doctor1.Specialization == specialization)
                        {
                            doctors.Add(doctor1);
                            searched = true;
                        }
                    }

                    if (!searched)
                    {
                        Console.WriteLine("No doctor data found with the given name.\n");
                    }
                }
            }
            else
            {
                Console.WriteLine("Doctor.txt file does not exist.\n");
            }

            return doctors;
        }

    }
}

