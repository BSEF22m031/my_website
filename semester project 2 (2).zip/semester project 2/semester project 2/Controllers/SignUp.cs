﻿using Microsoft.AspNetCore.Mvc;

namespace semester_project_2.Controllers
{
    public class SignUp : Controller
    {
        public IActionResult signup()
        {
            return View();
        }
    }
}
