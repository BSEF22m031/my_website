﻿using Microsoft.AspNetCore.Mvc;

namespace semester_project_2.Controllers
{
    public class CastVoteController : Controller
    {
        public IActionResult castVote()
        {
            return View();
        }
    }
}
