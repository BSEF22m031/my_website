﻿using Microsoft.AspNetCore.Mvc;

namespace semester_project_2.Controllers
{
    public class LoginPage : Controller
    {
        public IActionResult login()
        {
            return View();
        }
    }
}
