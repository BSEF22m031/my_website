﻿using Microsoft.AspNetCore.Mvc;

namespace semester_project_2.Controllers
{
    public class UpcomingRegisterController : Controller
    {
        public IActionResult upcomingRegister()
        {
            return View();
        }
    }
}
