﻿using Microsoft.AspNetCore.Mvc;

namespace semester_project_2.Controllers
{
    public class UpcomingElectionsController : Controller
    {
        public IActionResult upcomingElection()
        {
            return View();
        }
    }
}
