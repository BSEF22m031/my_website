﻿using Microsoft.AspNetCore.Mvc;

namespace semester_project_2.Controllers
{
    public class VoteCastingController : Controller
    {
        public IActionResult voteCasting()
        {
            return View();
        }
    }
}
